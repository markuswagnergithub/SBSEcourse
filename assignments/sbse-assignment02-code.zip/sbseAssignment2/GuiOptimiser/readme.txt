All of the three apps (GuiOptimiser, simpleApp and calculator) and the color.csv have to be in the same dir.

Color.csv file has the color (RGB) values for each GUI component.
e.g.
jTextField1,211,100,43
 // the background color of jTextField1
jTextField1TextColor,236,88,181 // the foreground (text) color of jTextField1

To run the GuiOptimiser app
java -jar GuiOptimiser.jar "the target app"
e.g. java -jar GuiOptimiser.jar simpleApp.jar


If you have any questions please post them on the course forum.

Good Luck,
Mahmoud.